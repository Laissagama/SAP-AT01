var prompt = require("prompt-sync")()

var base = prompt("Digite a base do rentângulo: ")
var altura = prompt("Digite a altura do rentângulo: ")
var area = base * altura

console.log(area)

